﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyCopyright("Copyright © 2008")]
[assembly: AssemblyDescription("Contains tests for the FileGenerator add-in.")]
[assembly: AssemblyFileVersion("5.0.0.0")]
[assembly: AssemblyProduct("FileGenerator.Tests")]
[assembly: AssemblyTitle("FileGenerator.Tests")]
[assembly: AssemblyVersion("5.0.0.0")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ReflectionPermission(SecurityAction.RequestMinimum, Unrestricted = true)]