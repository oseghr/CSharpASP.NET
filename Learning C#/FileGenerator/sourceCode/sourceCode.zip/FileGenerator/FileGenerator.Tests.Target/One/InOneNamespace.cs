﻿using System;

namespace FileGenerator.Tests.Target.One
{
	public sealed class InOneNamespace
	{
		public int DoSomething(int x)
		{
			return x * 2;
		}
	}
}
