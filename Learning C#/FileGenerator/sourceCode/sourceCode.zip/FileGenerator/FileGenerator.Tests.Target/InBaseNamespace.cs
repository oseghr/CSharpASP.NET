﻿using System;

namespace FileGenerator.Tests.Target
{
	public sealed class InBaseNamespace
	{
		public int DoSomething(int x)
		{
			return x * 2;
		}
	}
}
