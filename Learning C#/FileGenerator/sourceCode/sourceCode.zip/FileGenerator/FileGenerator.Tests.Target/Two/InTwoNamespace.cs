﻿using System;

namespace FileGenerator.Tests.Target.Two
{
	public sealed class InTwoNamespace
	{
		public int DoSomething(int x)
		{
			return x * 2;
		}
	}
}
