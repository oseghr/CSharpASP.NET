﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyCopyright("Copyright © 2008")]
[assembly: AssemblyDescription("A target to test the functionality of FileGenerator in FileGenerator.Tests.")]
[assembly: AssemblyFileVersion("5.0.0.0")]
[assembly: AssemblyProduct("FileGenerator.Tests.Target")]
[assembly: AssemblyTitle("FileGenerator.Tests.Target")]
[assembly: AssemblyVersion("5.0.0.0")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US")]
