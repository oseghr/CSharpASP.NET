![](Home_Screenshot.png)

**Project Description**
This is an add-in for Reflector - it generates code and resource files for a selected assembly, module, namespace, or type. It also creates a VS project file to see the generated files in Visual Studio.

Note that this project does NOT contain Reflector.exe. You have to download that assembly and reference it in the project to compile it. You also need to reference the Spackle assembly - the code for that project is here: [http://www.codeplex.com/Spackle](http://www.codeplex.com/Spackle). Note that this assembly is included in the release.